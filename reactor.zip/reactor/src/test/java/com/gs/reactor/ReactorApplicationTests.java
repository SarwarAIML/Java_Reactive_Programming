package com.gs.reactor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactorApplicationTests {

	@Test
	void contextLoads() {
	}

}
